VØID MUSIC — prototype PWA

Ce dossier contient une première maquette installable comme application web sur iPhone.
Important : cette version est une maquette d'interface. Les titres affichés sont des exemples non jouables.
Elle ne contient pas de catalogue musical commercial et ne contourne aucune publicité ni abonnement.

Pour l'installer sur iPhone :
1. Héberger tout le contenu de ce dossier sur un site HTTPS (par exemple GitHub Pages).
2. Ouvrir l'adresse du site dans Safari sur l'iPhone.
3. Appuyer sur Partager > Sur l'écran d'accueil > Ajouter.

Pour activer un vrai catalogue de streaming, il faudra intégrer un fournisseur/API qui autorise explicitement la lecture dans une application tierce, avec les droits et conditions correspondants.
